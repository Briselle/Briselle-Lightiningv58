import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ZIVA_ROLES,
  getAnswerForMessage,
  getSuggestedQuestions,
  getNavLinksForMessage,
  shouldShowContactForm,
} from './zivaKnowledge.js';
import SimpleZivaContactForm from './SimpleZivaContactForm.jsx';
import { mergeZivaConfig } from './defaultConfig.js';
import './ZivaChat.css';

const TYPEWRITER_SPEED_MS = 8;
const TYPEWRITER_CHUNK = 2;

function TypewriterText({ text, speed = TYPEWRITER_SPEED_MS, chunkSize = TYPEWRITER_CHUNK, onComplete }) {
  const [visibleLength, setVisibleLength] = useState(0);
  const onCompleteRef = useRef(onComplete);
  const doneRef = useRef(false);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    if (!text || visibleLength >= text.length) {
      if (visibleLength >= text.length && !doneRef.current && onCompleteRef.current) {
        doneRef.current = true;
        onCompleteRef.current();
      }
      return;
    }
    const id = setTimeout(() => {
      setVisibleLength((prev) => Math.min(prev + chunkSize, text.length));
    }, speed);
    return () => clearTimeout(id);
  }, [text, visibleLength, speed, chunkSize]);

  const display = text ? text.slice(0, visibleLength) : '';
  const isComplete = visibleLength >= (text?.length ?? 0);
  return (
    <>
      {display}
      {!isComplete && (
        <span className="ziva-typewriter-cursor" aria-hidden="true">
          |
        </span>
      )}
    </>
  );
}

function resolveApiBaseUrl(cfg) {
  if (cfg.api?.baseUrl) return cfg.api.baseUrl;
  try {
    const v = typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_ZIVA_API_URL;
    if (v) return v;
  } catch {
    /* non-Vite */
  }
  return '/api/ziva';
}

/**
 * Floating ZIVA chat widget.
 * @param {object} [props]
 * @param {import('./defaultConfig.js').defaultZivaConfig} [props.config] Partial overrides for strings, routes, assets, API, auth.
 * @param {React.ComponentType} [props.contactFormComponent] Replace the default simple contact form (e.g. wire Supabase OTP from your app).
 */
export default function ZivaChat({ config: userConfig, contactFormComponent: ContactFormOverride }) {
  const cfg = mergeZivaConfig(userConfig);
  const navigate = useNavigate();
  const openLogin = cfg.auth?.openLogin;
  const openSignup = cfg.auth?.openSignup;

  const ZIVA_CHAT_CACHE_KEY = cfg.storageKey;
  const ZIVA_CHAT_CACHE_TTL_MS = cfg.cacheTtlMs;

  function loadChatCache() {
    try {
      if (typeof localStorage === 'undefined') return null;
      const raw = localStorage.getItem(ZIVA_CHAT_CACHE_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      if (!data || !Array.isArray(data.messages)) return null;
      const age = Date.now() - (data.savedAt || 0);
      if (age > ZIVA_CHAT_CACHE_TTL_MS) return null;
      return data;
    } catch {
      return null;
    }
  }

  function saveChatCache(messages, role) {
    try {
      if (typeof localStorage === 'undefined') return;
      localStorage.setItem(
        ZIVA_CHAT_CACHE_KEY,
        JSON.stringify({
          messages,
          role: role ? { id: role.id, label: role.label } : null,
          savedAt: Date.now(),
        })
      );
    } catch {
      /* ignore */
    }
  }

  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState(() => {
    const cache = loadChatCache();
    if (!cache || !cache.messages || !cache.messages.length) return [];
    return cache.messages.map((m) => (m.from === 'bot' ? { ...m, typingComplete: true } : m));
  });
  const [role, setRole] = useState(() => {
    const cache = loadChatCache();
    if (!cache || !cache.role) return null;
    return ZIVA_ROLES.find((r) => r.id === cache.role.id) || null;
  });
  const [input, setInput] = useState('');
  const [suggestions, setSuggestions] = useState(getSuggestedQuestions(null));
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    setSuggestions(getSuggestedQuestions(role?.id ?? null));
  }, [role?.id]);

  useEffect(() => {
    if (messages.length > 0) saveChatCache(messages, role);
  }, [messages, role]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (open) {
      inputRef.current?.focus();
    }
  }, [open]);

  const apiUrl = resolveApiBaseUrl(cfg);
  const UNAVAILABLE_MSG = cfg.strings.apiUnavailablePrefix;

  const sendMessage = async (text) => {
    const trimmed = (text || input).trim();
    if (!trimmed) return;

    setInput('');
    setMessages((prev) => [...prev, { from: 'user', text: trimmed }]);

    const suggestedList = getSuggestedQuestions(role?.id ?? null);
    const useLocalOnly = suggestedList.some((q) => q.trim() === trimmed);

    let answer;
    if (useLocalOnly) {
      answer = getAnswerForMessage(trimmed);
      setMessages((prev) => [...prev, { from: 'bot', text: answer, question: trimmed, typingComplete: false }]);
      setSuggestions(getSuggestedQuestions(role));
      return;
    }

    try {
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: trimmed }),
      });
      const raw = await res.text();
      let data = {};
      try {
        data = raw ? JSON.parse(raw) : {};
      } catch {
        answer =
          res.status >= 500 ? UNAVAILABLE_MSG + getAnswerForMessage(trimmed) : getAnswerForMessage(trimmed);
        setMessages((prev) => [...prev, { from: 'bot', text: answer, question: trimmed, typingComplete: false }]);
        setSuggestions(getSuggestedQuestions(role));
        return;
      }
      if (res.ok && data.answer) {
        answer = data.answer;
      } else if (!res.ok && (res.status === 501 || res.status >= 500) && data.fallback) {
        answer = UNAVAILABLE_MSG + getAnswerForMessage(trimmed);
      } else {
        answer = getAnswerForMessage(trimmed);
      }
    } catch {
      answer = UNAVAILABLE_MSG + getAnswerForMessage(trimmed);
    }

    setMessages((prev) => [...prev, { from: 'bot', text: answer, question: trimmed, typingComplete: false }]);
    setSuggestions(getSuggestedQuestions(role));
  };

  const selectRole = (r) => {
    setRole(r);
    setSuggestions(getSuggestedQuestions(r?.id || null));
    setMessages((prev) => [
      ...prev,
      {
        from: 'bot',
        text: cfg.strings.roleConfirm(r?.label || 'visitor'),
        typingComplete: false,
      },
    ]);
  };

  const openTalkToUs = () => {
    setOpen(true);
    setMessages((prev) => [
      ...prev,
      {
        from: 'bot',
        text: cfg.strings.contactIntroBot,
        showContactForm: true,
        typingComplete: false,
      },
    ]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage(input);
  };

  const showWelcome = messages.length === 0;

  const ContactForm = ContactFormOverride || SimpleZivaContactForm;
  const contactExtraProps = ContactFormOverride ? {} : { submitUrl: cfg.contactSubmitUrl, submitButtonLabel: 'Send' };

  return (
    <div className="ziva-chat-wrapper" aria-label="ZIVA chat">
      <div className={`ziva-chat-panel ${open ? 'ziva-chat-panel-open' : ''}`}>
        <div className="ziva-chat-header">
          <div className="ziva-chat-header-brand">
            <span className="ziva-chat-logo" aria-hidden="true">
              Z
              <span className="ziva-logo-i-wrap">
                <img src={cfg.assets.sparkle} alt="" className="ziva-logo-sparkle" />I
              </span>
              VA
            </span>
            <span className="ziva-chat-tagline">{cfg.tagline}</span>
          </div>
          <div className="ziva-chat-header-actions">
            <Link to={cfg.routes.learnMorePath} className="ziva-chat-link-page" onClick={() => setOpen(false)}>
              {cfg.routes.learnMoreLabel}
            </Link>
            <button
              type="button"
              className="ziva-chat-close"
              onClick={() => setOpen(false)}
              aria-label={cfg.strings.closePanelAria}
            >
              <i className="fas fa-times" />
            </button>
          </div>
        </div>

        <div className="ziva-chat-body">
          {showWelcome && (
            <div className="ziva-chat-welcome">
              <p className="ziva-chat-welcome-text">{cfg.strings.welcomeMessage}</p>
              <p className="ziva-chat-role-prompt">{cfg.strings.rolePrompt}</p>
              <div className="ziva-chat-roles">
                {ZIVA_ROLES.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    className={`ziva-role-tag ${role?.id === r.id ? 'ziva-role-tag-active' : ''}`}
                    onClick={() => selectRole(r)}
                  >
                    <i className={`fas ${r.icon}`} aria-hidden="true" />
                    <span>{r.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="ziva-chat-messages">
            {messages.map((msg, i) => (
              <div key={i} className={`ziva-msg-block ziva-msg-block-${msg.from}`}>
                <div className={`ziva-msg ziva-msg-${msg.from}`} role={msg.from === 'bot' ? 'status' : undefined}>
                  {msg.from === 'bot' && (
                    <div className="ziva-msg-avatar" aria-hidden="true">
                      <img src={cfg.assets.logo} alt="" className="ziva-avatar-logo" />
                    </div>
                  )}
                  <div className="ziva-msg-bubble">
                    <p>
                      {msg.from === 'bot' && msg.typingComplete !== true ? (
                        <TypewriterText
                          text={msg.text}
                          onComplete={() => {
                            setMessages((prev) =>
                              prev.map((m, idx) => (idx === i ? { ...m, typingComplete: true } : m))
                            );
                          }}
                        />
                      ) : (
                        msg.text
                      )}
                    </p>
                  </div>
                </div>
                {msg.from === 'bot' && msg.typingComplete === true && (
                  <>
                    <div className="ziva-msg-nav">
                      <span className="ziva-nav-label">{cfg.strings.navigateLabel}</span>
                      <div className="ziva-nav-links">
                        {getNavLinksForMessage(msg.text).map((link, j) =>
                          link.action === 'open_contact' ? (
                            <button
                              key={`${j}-${link.label}`}
                              type="button"
                              className="ziva-nav-link ziva-nav-action"
                              onClick={openTalkToUs}
                            >
                              {link.label}
                            </button>
                          ) : link.url === '/login' && typeof openLogin === 'function' ? (
                            <button
                              key={`${j}-${link.label}`}
                              type="button"
                              className="ziva-nav-link ziva-nav-action"
                              onClick={() => {
                                setOpen(false);
                                openLogin();
                              }}
                            >
                              {link.label}
                            </button>
                          ) : link.url === '/signup' && typeof openSignup === 'function' ? (
                            <button
                              key={`${j}-${link.label}`}
                              type="button"
                              className="ziva-nav-link ziva-nav-action"
                              onClick={() => {
                                setOpen(false);
                                openSignup();
                              }}
                            >
                              {link.label}
                            </button>
                          ) : link.url?.startsWith('http') ? (
                            <a
                              key={`${j}-${link.label}`}
                              href={link.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="ziva-nav-link"
                            >
                              {link.label}
                            </a>
                          ) : link.url?.startsWith('/#') ? (
                            <button
                              type="button"
                              key={`${j}-${link.label}`}
                              className="ziva-nav-link ziva-nav-action"
                              onClick={() => {
                                setOpen(false);
                                navigate(cfg.routes.homePath, { replace: true });
                                const id = link.url.slice(2);
                                setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }), 100);
                              }}
                            >
                              {link.label}
                            </button>
                          ) : (
                            <Link
                              key={`${j}-${link.label}`}
                              to={link.url}
                              replace
                              className="ziva-nav-link"
                              onClick={() => setOpen(false)}
                            >
                              {link.label}
                            </Link>
                          )
                        )}
                      </div>
                    </div>
                    {(msg.showContactForm || (msg.question != null && shouldShowContactForm(msg.question, msg.text))) && (
                      <div className="ziva-msg-contact">
                        <ContactForm {...contactExtraProps} />
                      </div>
                    )}
                  </>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {messages.length > 0 && suggestions.length > 0 && (
            <div className="ziva-chat-suggestions">
              <span className="ziva-suggestions-label">{cfg.strings.suggestionsLabel}</span>
              <div className="ziva-suggestions-chips">
                {suggestions.slice(0, 4).map((q, idx) => (
                  <button key={idx} type="button" className="ziva-suggestion-chip" onClick={() => sendMessage(q)}>
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <form className="ziva-chat-footer" onSubmit={handleSubmit}>
          <input
            ref={inputRef}
            type="text"
            className="ziva-chat-input"
            placeholder={cfg.strings.inputPlaceholder}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            aria-label={cfg.strings.messageZivaAria}
          />
          <button type="submit" className="ziva-chat-send" aria-label={cfg.strings.sendAria}>
            <i className="fas fa-paper-plane" />
          </button>
        </form>
      </div>

      <button
        type="button"
        className={`ziva-chat-fab ${open ? 'ziva-chat-fab-open' : ''}`}
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? cfg.strings.closeChatAria : cfg.strings.openChatAria}
        aria-expanded={open}
      >
        <span className="ziva-fab-circle">
          <img src={cfg.assets.logo} alt="" className="ziva-fab-logo" />
          <img src={cfg.assets.sparkle} alt="" className="ziva-fab-sparkle" />
          <span className="ziva-fab-ai-tag" aria-hidden="true">
            AI
          </span>
        </span>
        <span className="ziva-fab-label">{cfg.fabLabel}</span>
      </button>
    </div>
  );
}
