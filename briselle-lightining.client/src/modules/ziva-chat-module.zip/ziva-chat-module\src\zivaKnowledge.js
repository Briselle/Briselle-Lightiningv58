/**
 * ZIVA – Briselle EdTech AI: knowledge base and suggested questions.
 * Answers are keyed by normalized question phrases; can be extended with an LLM API later.
 * For a subdomain or other product, edit FAQ, SUGGESTED_QUESTIONS, NAV_LINKS, and CONTENT_TO_LINK.
 */

export const ZIVA_ROLES = [
  { id: 'teacher', label: 'Teacher', icon: 'fa-chalkboard-teacher' },
  { id: 'student', label: 'Student', icon: 'fa-user-graduate' },
  { id: 'parent', label: 'Parent', icon: 'fa-users' },
  { id: 'administrator', label: 'Administrator', icon: 'fa-user-cog' },
  { id: 'institution', label: 'Institution', icon: 'fa-school' },
  { id: 'counselor', label: 'Counselor', icon: 'fa-user-tie' },
  { id: 'researcher', label: 'Researcher', icon: 'fa-flask' },
  { id: 'government', label: 'Government', icon: 'fa-landmark' },
];

/** Normalize for matching: lowercase, trim, collapse spaces */
function norm(s) {
  return String(s)
    .toLowerCase()
    .trim()
    .replace(/\s+/g, ' ');
}

/** FAQ: question patterns (substrings after norm) -> answer */
const FAQ = [
  [
    ['what is briselle', 'who is briselle', 'tell me about briselle'],
    'Briselle™ is an AI-driven EdTech exchange by Birselle Private Limited. We connect the entire education ecosystem—students, teachers, parents, administrators, institutions, counselors, and more—with intelligent automation, personalized learning, and streamlined workflows. Think of us as the central hub where learning, teaching, and administration meet AI.',
  ],
  [
    ['what can briselle do', 'what does briselle do', 'features', 'capabilities'],
    'Briselle offers: AI-powered learning analytics and personalized study plans, automated grading and feedback for teachers, parent engagement and progress reports, workflow automation for administrators, integrations with LMS and tools, and an ecosystem that serves students, teachers, parents, schools, institutions, counselors, and regulators. Explore our Features and AI Exchange sections on the homepage for details.',
  ],
  [
    ['ai exchange', 'what is ai exchange'],
    "The AI Exchange is Briselle's intelligent layer that adapts to each learner. It includes AI student profiles, predictive analytics, developmental tracking, personalized learning paths, and automated insights for teachers and parents. It's designed to make education more personalized and data-driven.",
  ],
  [
    ['stakeholders', 'who is it for', 'who can use'],
    'Briselle serves the full education ecosystem: Students (personalized plans, homework help), Teachers (grading, insights, reports), Parents (progress, communication), Administrators (workflows, operations), Institutions (strategy, enrollment), Counselors (risk assessment, career paths), Researchers, Government, and more. Choose your role in this chat to see tailored info!',
  ],
  [
    ['contact', 'how to contact', 'email', 'phone', 'support'],
    'You can reach us at info@briselle.com or call +91 998-050-9943. For support and help, visit our Help Centre. You can also use the Contact page or the "Talk to us" option in this chat.',
  ],
  [
    ['pricing', 'cost', 'plans', 'price'],
    'For pricing and plans, please visit our website or contact us at info@briselle.com. We offer solutions tailored to institutions, schools, and individual stakeholders.',
  ],
  [
    ['sign up', 'register', 'get started', 'demo'],
    'You can Sign Up or request a Demo from the main navigation. Our team will help you get started with Briselle based on your role and institution.',
  ],
  [
    ['teachers', 'for teachers', 'teacher benefits'],
    'For teachers, Briselle offers AI-powered grading and feedback, student insights and at-risk detection, automated reports for parents and admins, and tools to save time while improving outcomes. Check the Stakeholders section for more.',
  ],
  [
    ['students', 'for students', 'student benefits'],
    'Students get personalized study plans, 24/7 AI homework help, progress tracking, and learning paths that adapt to their strengths and needs. Our AI Exchange powers these experiences.',
  ],
  [
    ['parents', 'for parents', 'parent benefits'],
    "Parents stay connected with automated progress reports, teacher communication, and visibility into their child's learning—all in one place.",
  ],
  [
    ['integrations', 'lms', 'integrate'],
    'Briselle integrates with popular LMS and EdTech tools. Our Integrations section on the homepage and Documentation cover available connectors and APIs.',
  ],
  [
    ['api', 'developer', 'documentation'],
    'We provide an API and documentation for developers and institutions. Visit the API and Documentation pages from the footer or navigation for technical details.',
  ],
  [
    ['help', 'how can you help', 'what can you help with', 'what can i ask'],
    'I can answer questions about Briselle—what we do, who we serve, features, AI Exchange, stakeholders, contact, sign up, and more. Choose your role above to get tailored suggestions, or type any question about Briselle or this website.',
  ],
  [
    ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening'],
    "Hello! I'm ZIVA, your Briselle EdTech assistant. What would you like to know about Briselle or our website? You can pick a role or ask anything.",
  ],
  [
    ['thanks', 'thank you', 'bye', 'goodbye'],
    "You're welcome! If you have more questions, just ask. Have a great day!",
  ],
];

export const defaultAnswer =
  "I'm not sure about that specific detail. I can tell you about what Briselle is, our features, AI Exchange, stakeholders, contact info, sign up, and more. Try asking something like: What is Briselle? or What can Briselle do for teachers?";

/**
 * Get answer for a user message (normalized). Returns string.
 */
export function getAnswerForMessage(text) {
  const n = norm(text);
  if (!n) return 'Type a question about Briselle or pick one of the suggestions above!';
  for (const [patterns, answer] of FAQ) {
    if (patterns.some((p) => n.includes(p))) return answer;
  }
  return defaultAnswer;
}

/** Suggested questions shown in chat (by role or general) */
export const SUGGESTED_QUESTIONS = {
  general: [
    'What is Briselle?',
    'What can Briselle do for me?',
    'Who is Briselle for?',
    'How do I contact Briselle?',
    'Tell me about the AI Exchange',
    'How do I sign up or get a demo?',
  ],
  teacher: [
    'What can teachers do with Briselle?',
    'How does AI help with grading?',
    'How do I get student insights?',
  ],
  student: [
    'What do students get from Briselle?',
    'Is there homework help?',
    'How does the study plan work?',
  ],
  parent: [
    'How can parents use Briselle?',
    "How do I see my child's progress?",
    'How do I talk to teachers?',
  ],
  administrator: [
    'What can administrators do?',
    'How does workflow automation work?',
    'How do we integrate with our LMS?',
  ],
  institution: [
    'What does Briselle offer institutions?',
    'Enrollment and strategy tools?',
    'API and integrations?',
  ],
  counselor: [
    'What tools do counselors have?',
    'Risk assessment and early warning?',
    'Career path recommendations?',
  ],
  researcher: ['Research and analytics on the platform?', 'Data and insights for studies?'],
  government: ['Compliance and policy tools?', 'How does Briselle work with regulators?'],
};

export function getSuggestedQuestions(roleId) {
  if (roleId && SUGGESTED_QUESTIONS[roleId]) {
    return [...SUGGESTED_QUESTIONS[roleId], ...SUGGESTED_QUESTIONS.general.slice(0, 2)];
  }
  return SUGGESTED_QUESTIONS.general;
}

/** Default navigation links below every answer. Use url for links or action: 'open_contact' for in-chat form. */
export const NAV_LINKS = [
  { label: 'Talk to us', action: 'open_contact' },
  { label: 'Contact', url: '/contact' },
  { label: 'Help Centre', url: '/help' },
  { label: 'Features', url: '/#features' },
  { label: 'Blog', url: '/blog' },
  { label: 'Sign-in', url: '/login' },
  { label: 'Sign up', url: '/signup' },
];

/** Keyword → nav link (label, url). Used to add dynamic links from message content. */
const CONTENT_TO_LINK = [
  { keywords: ['contact', 'email', 'phone', 'reach', 'support'], label: 'Contact', url: '/contact' },
  { keywords: ['help', 'support', 'faq'], label: 'Help Centre', url: '/help' },
  { keywords: ['feature', 'features', 'capabilities'], label: 'Features', url: '/#features' },
  { keywords: ['blog', 'article', 'post'], label: 'Blog', url: '/blog' },
  { keywords: ['sign up', 'signup', 'register', 'demo'], label: 'Sign up', url: '/signup' },
  { keywords: ['sign in', 'signin', 'login', 'account'], label: 'Sign-in', url: '/login' },
  { keywords: ['about', 'mission', 'vision'], label: 'About', url: '/about' },
  { keywords: ['ziva', 'assistant', 'chat'], label: 'ZIVA', url: '/ziva' },
  { keywords: ['documentation', 'api', 'developer'], label: 'Documentation', url: '/documentation' },
  { keywords: ['integration', 'lms'], label: 'Integrations', url: '/#integrations' },
  { keywords: ['stakeholder', 'teacher', 'student', 'parent'], label: 'Stakeholders', url: '/#stakeholders' },
];

/** Dynamic links derived from bot message content (retains default; add extras by keyword match). */
export function getNavLinksForMessage(messageText) {
  const text = (messageText || '').toLowerCase();
  const seen = new Set(NAV_LINKS.map((l) => (l.label || l.url || '').toLowerCase()));
  const out = [...NAV_LINKS];
  for (const { keywords, label, url } of CONTENT_TO_LINK) {
    if (seen.has(label.toLowerCase())) continue;
    if (keywords.some((k) => text.includes(k))) {
      out.push({ label, url });
      seen.add(label.toLowerCase());
    }
  }
  return out;
}

/** Whether this message is a known suggested question (exact match). */
export function isSuggestedQuestion(text, roleId) {
  const trimmed = String(text).trim();
  const list = getSuggestedQuestions(roleId);
  return list.some((q) => q.trim() === trimmed);
}

/** Whether we should show the contact form (contact-related or AI couldn't answer). */
export function shouldShowContactForm(text, answer) {
  const n = norm(text);
  const contactPatterns = ['contact', 'how to contact', 'email', 'phone', 'support', 'reach', 'talk to', 'speak to'];
  const isContactQuestion = contactPatterns.some((p) => n.includes(p));
  const isDefaultAnswer = answer === defaultAnswer;
  return isContactQuestion || isDefaultAnswer;
}
