/**
 * ZIVA Groq API — Express router. Provide `getContext()` returning a string (markdown/plain) for the model.
 *
 * @example
 * import express from 'express';
 * import { createZivaApiRouter } from './node_modules/.../createZivaApi.mjs';
 * const app = express();
 * app.use(express.json());
 * app.use(createZivaApiRouter({ getContext: () => fs.readFileSync('./context.md', 'utf8') }));
 */

import express from 'express';

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const DEFAULT_MODEL = 'llama-3.1-8b-instant';

function safeSendJson(res, status, body) {
  if (res.headersSent) return;
  res.status(status).set('Content-Type', 'application/json').end(JSON.stringify(body));
}

function buildSystemPrompt(contextString, productName, baseSiteUrl) {
  return `You are ZIVA, the Zenith Intelligent Virtual Assistant for ${productName} (${baseSiteUrl}). You answer ONLY using the following content. Do not use external knowledge.

RULES:
1. Answer only from the provided context. If the answer is not in the context, say you can only answer about ${productName} and suggest visiting ${baseSiteUrl} or official contact channels that appear in the context.
2. Be helpful, concise, and friendly.
3. When relevant, add navigation hints using only URLs present in the context.
4. Do not make up features, contact details, or URLs.

CONTEXT:
${contextString}`;
}

/**
 * @param {object} options
 * @param {() => string} options.getContext Sync function returning full context text.
 * @param {string} [options.productName]
 * @param {string} [options.baseSiteUrl]
 * @param {string} [options.model] Groq model id.
 * @param {boolean} [options.cacheContext] If true (default), call getContext() once and reuse.
 */
export function createZivaApiRouter(options) {
  const {
    getContext,
    productName = 'Briselle',
    baseSiteUrl = 'https://www.briselle.com',
    model = DEFAULT_MODEL,
    cacheContext = true,
  } = options;

  if (typeof getContext !== 'function') {
    throw new Error('createZivaApiRouter: getContext is required');
  }

  let cachedContext = null;

  function resolveContextString() {
    if (cacheContext && cachedContext !== null) return cachedContext;
    const ctx = getContext();
    if (typeof ctx !== 'string') {
      throw new Error('createZivaApiRouter: getContext() must return a string');
    }
    if (cacheContext) cachedContext = ctx;
    return ctx;
  }

  async function handleZiva(req, res) {
    const question = typeof req.body?.question === 'string' ? req.body.question.trim() : '';
    const apiKey = process.env.GROQ_API_KEY;

    if (!question) {
      return safeSendJson(res, 400, { error: 'Missing question' });
    }

    if (!apiKey) {
      return safeSendJson(res, 501, { error: 'AI not configured', fallback: true });
    }

    try {
      let contextString;
      try {
        contextString = resolveContextString();
      } catch (ctxErr) {
        console.error('ZIVA context error', ctxErr);
        return safeSendJson(res, 502, { error: 'AI temporarily unavailable', fallback: true });
      }

      const systemPrompt = buildSystemPrompt(contextString, productName, baseSiteUrl);

      const response = await fetch(GROQ_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: question },
          ],
          max_tokens: 512,
          temperature: 0.3,
        }),
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error('Groq API error', response.status, errText);
        return safeSendJson(res, 502, { error: 'AI temporarily unavailable', fallback: true });
      }

      const rawBody = await response.text();
      let data = {};
      try {
        data = rawBody ? JSON.parse(rawBody) : {};
      } catch (parseErr) {
        console.error('Groq response not JSON', parseErr?.message);
        return safeSendJson(res, 502, { error: 'AI temporarily unavailable', fallback: true });
      }
      const content = data?.choices?.[0]?.message?.content?.trim();
      if (!content) {
        return safeSendJson(res, 502, { error: 'Empty AI response', fallback: true });
      }

      return safeSendJson(res, 200, { answer: content });
    } catch (err) {
      console.error('ZIVA API error', err);
      return safeSendJson(res, 502, { error: 'AI temporarily unavailable', fallback: true });
    }
  }

  const router = express.Router();
  router.post('/api/ziva', (req, res) => {
    Promise.resolve(handleZiva(req, res)).catch((err) => {
      console.error('ZIVA unhandled', err);
      if (!res.headersSent) safeSendJson(res, 502, { error: 'AI temporarily unavailable', fallback: true });
    });
  });

  return router;
}
