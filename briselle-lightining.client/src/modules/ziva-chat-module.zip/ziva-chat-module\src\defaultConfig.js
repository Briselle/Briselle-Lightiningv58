/**
 * Default Briselle marketing-site behaviour. In another app (e.g. subdomain),
 * merge a partial config into this object — swap routes, strings, assets, and API URL.
 */

export const defaultZivaConfig = {
  /** localStorage key for persisted panel state */
  storageKey: 'ziva_chat_cache',
  cacheTtlMs: 24 * 60 * 60 * 1000,

  strings: {
    welcomeMessage:
      'Hi, I am ZIVA, your EdTech AI. What can I help you with today?',
    rolePrompt:
      'Choose your role so I can tailor suggestions for you—or ask anything about Briselle.',
    roleConfirm: (label) =>
      `Got it! I'll tailor suggestions for you as a ${label}. What would you like to know?`,
    inputPlaceholder: 'Ask about Briselle...',
    suggestionsLabel: 'Suggested:',
    openChatAria: 'Open ZIVA chat',
    closeChatAria: 'Close ZIVA chat',
    messageZivaAria: 'Message ZIVA',
    sendAria: 'Send',
    closePanelAria: 'Close chat',
    navigateLabel: 'Navigate:',
    apiUnavailablePrefix:
      'ZIVA AI is not available right now. Please ensure the ZIVA server is running with GROQ_API_KEY set. Meanwhile: ',
    contactIntroBot:
      "Here's how you can reach us. Fill in the form below and we'll get back to you.",
  },

  routes: {
    learnMorePath: '/ziva',
    learnMoreLabel: 'Learn more',
    /** Used for /#section hash navigation from nav links */
    homePath: '/',
  },

  assets: {
    logo: '/assets/briselle-logo.png',
    sparkle: '/assets/ziva_sparkle_white.svg',
  },

  api: {
    /** If null, uses import.meta.env.VITE_ZIVA_API_URL or '/api/ziva' */
    baseUrl: null,
  },

  /**
   * Optional: wire to your modals (main site). If omitted, login/signup nav uses router only.
   */
  auth: {
    openLogin: null,
    openSignup: null,
  },

  /**
   * POST JSON { name, email, message } — used by SimpleZivaContactForm when not overridden.
   */
  contactSubmitUrl: null,

  /** Tagline under ZIVA logo in header */
  tagline: 'AI for EdTech',
  fabLabel: 'ZIVA',
};

export function mergeZivaConfig(partial) {
  if (!partial) return { ...defaultZivaConfig, strings: { ...defaultZivaConfig.strings } };
  return {
    ...defaultZivaConfig,
    ...partial,
    strings: { ...defaultZivaConfig.strings, ...(partial.strings || {}) },
    routes: { ...defaultZivaConfig.routes, ...(partial.routes || {}) },
    assets: { ...defaultZivaConfig.assets, ...(partial.assets || {}) },
    api: { ...defaultZivaConfig.api, ...(partial.api || {}) },
    auth: { ...defaultZivaConfig.auth, ...(partial.auth || {}) },
  };
}
