# ZIVA chat module (export pack)

This folder is a **portable copy** of the ZIVA floating chat, knowledge layer, optional marketing page, styles, and an Express router for the Groq-backed `/api/ziva` endpoint. The main Briselle site keeps richer wiring (Supabase OTP contact form, `siteContent.js` aggregation). Here, the chat uses a **simple JSON contact POST** unless you pass your own form component.

## Contents

| Path | Purpose |
|------|---------|
| `src/ZivaChat.jsx` | Widget: FAB, panel, typewriter, suggestions, local FAQ + API fallback |
| `src/ZivaChat.css` | All chat layout and visual design |
| `src/zivaKnowledge.js` | Roles, FAQ, suggestions, nav links, contact-form triggers |
| `src/defaultConfig.js` | Strings, routes, assets, API URL, auth callbacks — **override for subdomain apps** |
| `src/SimpleZivaContactForm.jsx` | Minimal name/email/message form (no Supabase) |
| `src/ZivaContactForm.css` | Contact strip styles |
| `src/ZivaPage.jsx` + `ZivaPage.css` | Landing page skeleton (sections, grid, CTAs) |
| `src/index.js` | Barrel exports |
| `server/createZivaApi.mjs` | `createZivaApiRouter({ getContext })` for Express |

## Assets (copy into your app `public/`)

The chat expects:

- `public/assets/briselle-logo.png` (or set `config.assets.logo`)
- `public/assets/ziva_sparkle_white.svg` (or set `config.assets.sparkle`)

Copy these from your Briselle portal `public` build or asset pipeline if they are not in the repo snapshot.

## React integration (Vite or similar)

1. Copy this entire `ziva-chat-module` folder into your project (e.g. `src/vendor/ziva-chat-module/`).

2. Install peers: `react`, `react-dom`, `react-router-dom`.

3. Load **Font Awesome** (icons: `fa-times`, `fa-paper-plane`, role icons) the same way your main site does, or swap icons in `zivaKnowledge.js` / JSX.

4. Import CSS once (e.g. in your root layout):

```jsx
import ZivaChat from './vendor/ziva-chat-module/src/ZivaChat.jsx';
import './vendor/ziva-chat-module/src/ZivaChat.css';
```

5. Render inside a `BrowserRouter` (uses `Link` / `useNavigate`):

```jsx
<ZivaChat
  config={{
    strings: {
      rolePrompt: 'Choose your role—or ask anything about this workspace.',
      inputPlaceholder: 'Ask a question…',
    },
    routes: { learnMorePath: '/help/ziva', learnMoreLabel: 'About ZIVA', homePath: '/' },
    assets: { logo: '/assets/your-logo.png', sparkle: '/assets/ziva_sparkle_white.svg' },
    api: { baseUrl: import.meta.env.VITE_ZIVA_API_URL },
    auth: {
      openLogin: () => { /* your subdomain auth */ },
      openSignup: () => { /* ... */ },
    },
    contactSubmitUrl: '/api/ziva-contact',
  }}
/>
```

6. Optional: replace the contact form with your Briselle OTP form (or subdomain logic):

```jsx
import ZivaChat from '...';
import BriselleZivaContactForm from './BriselleZivaContactForm';

<ZivaChat contactFormComponent={BriselleZivaContactForm} />
```

7. Environment: set `VITE_ZIVA_API_URL` to your API origin if the chat is not same-origin (see `example.env.ziva.txt`).

## Subdomain vs main site

- **Content & navigation**: edit `src/zivaKnowledge.js` (`FAQ`, `NAV_LINKS`, `SUGGESTED_QUESTIONS`, `CONTENT_TO_LINK` patterns) so links match the subdomain router.
- **Branding**: override `config.assets`, `config.tagline`, `config.fabLabel`.
- **API behaviour**: implement `getContext()` in Node so ZIVA only answers from **that** app’s text (policies, features, URLs).

## Server (Express)

```bash
npm install express
```

```javascript
import express from 'express';
import { createZivaApiRouter } from './vendor/ziva-chat-module/server/createZivaApi.mjs';

const app = express();
app.use(express.json());
app.use(
  createZivaApiRouter({
    getContext: () => '## My product\n...markdown...',
    productName: 'My Subdomain App',
    baseSiteUrl: 'https://app.briselle.com',
  })
);
```

Set `GROQ_API_KEY` in the environment. For local parity with the main repo, you can still import `getFullBriselleContext` from `newportal/server/content/siteContent.js` inside `getContext` when this module lives alongside the monolith.

## Original files in `newportal` (reference)

- `src/components/ZivaChat.jsx`, `ZivaChat.css`
- `src/components/ZivaContactForm.jsx` (Supabase OTP)
- `src/data/zivaKnowledge.js`
- `src/pages/ZivaPage.jsx` + styles in `src/styles/app.css`
- `server/ziva-api.js`, `server/content/siteContent.js`

This export is meant to be **self-contained** and **config-driven** so you can evolve the subdomain app without forking JSX for every string.
