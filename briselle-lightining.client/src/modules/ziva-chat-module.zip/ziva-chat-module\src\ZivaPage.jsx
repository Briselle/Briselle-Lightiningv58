import { Link } from 'react-router-dom';
import { ZIVA_ROLES } from './zivaKnowledge.js';
import './ZivaPage.css';

/**
 * Standalone ZIVA landing section (outline + sections). Merge `pageConfig` for assets and CTA targets.
 * Add react-helmet-async in your app for SEO if needed.
 */
export default function ZivaPage({ pageConfig }) {
  const logo = pageConfig?.assets?.logo ?? '/assets/briselle-logo.png';
  const homePath = pageConfig?.homePath ?? '/';
  const contactPath = pageConfig?.contactPath ?? '/contact';

  return (
    <>
      <section className="ziva-page-hero">
        <div className="ziva-module-container">
          <div className="ziva-hero-content">
            <h1 className="ziva-hero-title">ZIVA</h1>
            <p className="ziva-hero-subtitle">AI for the Education Ecosystem</p>
            <p className="ziva-hero-desc">
              Your intelligent assistant for everything Briselle—and the first AI built specifically for EdTech.
              Whether you&apos;re a teacher, student, parent, administrator, or institution, ZIVA helps you discover
              what Briselle can do for you and answers questions about our platform and website.
            </p>
            <div className="ziva-hero-cta">
              <span className="ziva-hero-cta-hint">Look for the chat icon at the bottom right of any page.</span>
              <Link to={homePath} className="ziva-btn-primary">
                Go to Home
              </Link>
              <Link to={contactPath} className="ziva-btn-secondary">
                Contact Us
              </Link>
            </div>
          </div>
          <div className="ziva-hero-visual" aria-hidden="true">
            <div className="ziva-hero-icon">
              <img src={logo} alt="" className="ziva-hero-logo" />
            </div>
          </div>
        </div>
      </section>

      <section className="ziva-page-content-block">
        <div className="ziva-module-container">
          <h2>What ZIVA Can Do</h2>
          <p className="ziva-page-lead">One assistant for the whole education ecosystem</p>
          <div className="ziva-features-grid">
            <div className="ziva-feature-card">
              <i className="fas fa-comments" />
              <h3>Answer questions about Briselle</h3>
              <p>
                Ask about our platform, features, AI Exchange, stakeholders, contact info, sign up, demos, and more.
                ZIVA draws on Briselle&apos;s knowledge to give you clear, relevant answers.
              </p>
            </div>
            <div className="ziva-feature-card">
              <i className="fas fa-user-tag" />
              <h3>Role-based guidance</h3>
              <p>
                Choose your role—Teacher, Student, Parent, Administrator, Institution, Counselor, Researcher, or
                Government—and get tailored suggestions and information for your needs.
              </p>
            </div>
            <div className="ziva-feature-card">
              <i className="fas fa-bolt" />
              <h3>Instant, intuitive workflow</h3>
              <p>
                Welcome message, suggested questions, and quick-reply options so you can find what you need without
                typing. Same modern chat experience you expect from leading AI assistants.
              </p>
            </div>
            <div className="ziva-feature-card">
              <i className="fas fa-graduation-cap" />
              <h3>Built for EdTech</h3>
              <p>
                ZIVA isn&apos;t a generic chatbot—it&apos;s designed for the education ecosystem. From learning analytics
                and grading to parent engagement and institutional workflows, the answers are tuned for educators and
                learners.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="ziva-page-section ziva-roles-section">
        <div className="ziva-module-container">
          <h2 className="ziva-section-title">Stakeholders ZIVA Serves</h2>
          <p className="ziva-section-subtitle">Pick your role in the chat to get personalized suggestions.</p>
          <ul className="ziva-roles-list">
            {ZIVA_ROLES.map((r) => (
              <li key={r.id} className="ziva-role-card">
                <i className={`fas ${r.icon}`} />
                <span>{r.label}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="ziva-page-section ziva-cta-section">
        <div className="ziva-module-container">
          <h2>Try ZIVA Now</h2>
          <p>
            Use the chat widget at the bottom right of this page—or anywhere on the site—to start a conversation. No
            sign-up required to ask questions.
          </p>
          <p>
            <strong>Examples:</strong> &ldquo;What is Briselle?&rdquo; &ldquo;What can teachers do with
            Briselle?&rdquo; &ldquo;How do I contact you?&rdquo;
          </p>
        </div>
      </section>
    </>
  );
}
